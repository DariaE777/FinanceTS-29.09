import {Auth} from "../auth";
import host from "../config/config";
import {SignupResponseType} from "../types/signup-response.type";
import {DefaultResponseType} from "../types/default-response.type";
import {RefreshResponseType} from "../types/refresh-response.type";
export class SignUp {
    readonly openNewRoute: (arg0: string) => void;
    readonly nameElement: HTMLElement | null = document.getElementById('name');
    readonly lastNameElement: HTMLElement | null = document.getElementById('lastName');
    readonly emailElement: HTMLElement | null = document.getElementById('email');
    readonly passwordElement: HTMLElement | null = document.getElementById('password');
    readonly passwordRepeatElement: HTMLElement | null = document.getElementById('password-repeat');
    readonly formElement: HTMLElement | null = document.getElementById('form');
    readonly commonErrorElement: HTMLElement | null = document.getElementById('common-error');
    readonly processButtonElement: HTMLElement | null = document.getElementById('process-button');
    constructor(openNewRoute: (arg0: string) => void) {

        this.openNewRoute = openNewRoute;
        if (localStorage.getItem(Auth.accessTokenKey)) {
            this.openNewRoute('/');
        }
        if (this.processButtonElement) {
            this.processButtonElement.addEventListener('click', this.signUp.bind(this));
        }
    }
    private validateForm(): boolean {
        let isValid: boolean = true;
        if (this.nameElement && this.formElement && this.lastNameElement && this.emailElement && this.passwordElement
        && this.passwordRepeatElement) {
            if ((this.nameElement as HTMLInputElement).value && (this.nameElement as HTMLInputElement).value.match(/^[А-Я][а-я\s]*$/)) {
                this.formElement.classList.remove('was-validated');
                this.nameElement.classList.remove('is-invalid');
            } else {
                this.formElement.classList.add('was-validated');
                this.nameElement.classList.add('is-invalid');
                isValid = false;
            }
            if ((this.lastNameElement as HTMLInputElement).value && (this.lastNameElement as HTMLInputElement).value.match(/^[А-Я][а-я\s]*$/)) {
                this.formElement.classList.remove('was-validated');
                this.lastNameElement.classList.remove('is-invalid');
            } else {
                this.formElement.classList.add('was-validated');
                this.lastNameElement.classList.add('is-invalid');
                isValid = false;
            }
            if ((this.emailElement as HTMLInputElement).value && (this.emailElement as HTMLInputElement).value.match(/^\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/)) {
                this.formElement.classList.remove('was-validated');
                this.emailElement.classList.remove('is-invalid');
            } else {
                this.formElement.classList.add('was-validated');
                this.emailElement.classList.add('is-invalid');
                isValid = false;
            }
            if ((this.passwordElement as HTMLInputElement).value && (this.passwordElement as HTMLInputElement).value.match(/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])[0-9a-zA-Z]{8,}$/)) {
                this.formElement.classList.remove('was-validated');
                this.passwordElement.classList.remove('is-invalid');
            } else {
                this.formElement.classList.add('was-validated');
                this.passwordElement.classList.add('is-invalid');
                isValid = false;
            }

            if ((this.passwordRepeatElement as HTMLInputElement).value && (this.passwordRepeatElement as HTMLInputElement).value === (this.passwordElement as HTMLInputElement).value) {
                this.formElement.classList.remove('was-validated');
                this.passwordRepeatElement.classList.remove('is-invalid');
            } else {
                this.formElement.classList.add('was-validated');
                this.passwordRepeatElement.classList.add('is-invalid');
                isValid = false;
            }
        }
        return isValid;
    }

    private async signUp(): Promise<void> {
        if (this.commonErrorElement) {
            this.commonErrorElement.style.display = 'none';
        }

        if (this.validateForm()) {
           const response: Response = await fetch(host + 'signup', {
                method: 'POST',
                headers: {
                    'Content-type': 'application/json',
                    'Accept': 'application/json',
                },
                body: JSON.stringify({
                    name: (this.nameElement as HTMLInputElement).value,
                    lastName: (this.lastNameElement as HTMLInputElement).value,
                    email: (this.emailElement as HTMLInputElement).value,
                    password: (this.passwordElement as HTMLInputElement).value,
                    passwordRepeat: (this.passwordRepeatElement as HTMLInputElement).value
                })
            });
            const result: SignupResponseType | DefaultResponseType = await response.json();
            if ((result as DefaultResponseType).error || !(result as SignupResponseType).user.name || !(result as SignupResponseType).user.lastName || !(result as SignupResponseType).user.id || !(result as SignupResponseType).user.email) {
                if(this.commonErrorElement) {
                    this.commonErrorElement.style.display = 'block';
                }
                return;
            }
            localStorage.setItem(Auth.userInfoKey, JSON.stringify({
                id: (result as SignupResponseType).user.id,
                email: (result as SignupResponseType).user.email,
                name: (result as SignupResponseType).user.name,
                lastName: (result as SignupResponseType).user.lastName
            }));
            const response2: Response = await fetch(host + 'login', {
                method: 'POST',
                headers: {
                    'Content-type': 'application/json',
                    'Accept': 'application/json',
                },
                body: JSON.stringify({
                    email: (this.emailElement as HTMLInputElement).value,
                    password: (this.passwordElement as HTMLInputElement).value
                })
            });
            const result2: RefreshResponseType | DefaultResponseType= await response2.json();
            if ((result2 as DefaultResponseType).error || !(result2 as RefreshResponseType).tokens.accessToken || !(result2 as RefreshResponseType).tokens.refreshToken) {
                if (this.commonErrorElement) {
                    this.commonErrorElement.style.display = 'block';
                    return;
                }
            }
            if ((result2 as RefreshResponseType).tokens.accessToken && (result2 as RefreshResponseType).tokens.refreshToken) {
                Auth.setTokens((result2 as RefreshResponseType).tokens.accessToken, (result2 as RefreshResponseType).tokens.refreshToken);
            }
            this.openNewRoute('/');
        }
    }
}