import {Auth} from "../../auth";
import host from "../../config/config";
import {CategoriesResponseType} from "../../types/categories-response.type";
import {DefaultResponseType} from "../../types/default-response.type";

export class IncomeCreate {
    readonly openNewRoute: Function;
    readonly token: string | null;
    readonly refreshToken: string | null;
    readonly categoryTextElement: HTMLElement | null = document.getElementById('income-create-input');
    readonly incomeCreateButton: HTMLElement | null = document.getElementById('income-create');
    readonly incomeCreateCancelButton: HTMLElement | null = document.getElementById('income-create-cancel');
    readonly errorElement: HTMLElement | null = document.querySelector('.error-message');
    constructor(openNewRoute:Function) {
        this.openNewRoute = openNewRoute;
        this.token = localStorage.getItem(Auth.accessTokenKey);
        this.refreshToken = localStorage.getItem(Auth.refreshTokenKey);
        if (!this.token || !this.refreshToken) {
            return this.openNewRoute('/login');
        }
        if (this.incomeCreateButton){
            this.incomeCreateButton.addEventListener('click', this.createIncome.bind(this));
        }
        if (this.incomeCreateCancelButton){
            this.incomeCreateCancelButton.addEventListener('click', this.notCreate.bind(this));
        }
    }
    private async createIncome(e:MouseEvent): Promise<Response | undefined> {
        e.preventDefault();
        if ( this.errorElement && this.categoryTextElement && (this.categoryTextElement as HTMLInputElement).value) {
            this.errorElement.style.display = 'none';
            this.categoryTextElement.classList.add('mb-4');
            this.errorElement.style.color = '';
            this.errorElement.style.marginBottom = '';

            const categoryData = {
                title: (this.categoryTextElement as HTMLInputElement).value
            };
            const params: RequestInit = {
                method: 'POST',
                headers: {
                    'Content-type': 'application/json',
                    'Accept': 'application/json',
                    'x-auth-token': this.token ?? '',
                },
                body: JSON.stringify(categoryData)
            };

            const response = await fetch(host + 'categories/income', params);
            const result: CategoriesResponseType | DefaultResponseType = await response.json();
            if (!result || (result as DefaultResponseType).error) {
                if (response.status === 401) {
                    const updateTokenResult = await fetch(host + 'refresh', {
                        method: 'POST',
                        headers: {
                            'Content-type': 'application/json',
                            'Accept': 'application/json'
                        },
                        body: JSON.stringify({refreshToken: this.refreshToken})
                    });

                    if (updateTokenResult.status === 200) {
                        const tokens = await updateTokenResult.json();

                        if (tokens && !tokens.error) {
                            Auth.setTokens(tokens.tokens.accessToken, tokens.tokens.refreshToken);
                            return response;
                        }
                    } else {
                        Auth.removeTokens();
                        localStorage.removeItem(Auth.userInfoKey);
                        this.openNewRoute('/login');
                    }
                }
                this.openNewRoute('/login');
            }
            this.openNewRoute('/income');
        } else {
            if ( this.categoryTextElement &&  this.errorElement) {
                this.categoryTextElement.classList.remove('mb-4');
                this.errorElement.style.color = 'red';
                this.errorElement.style.marginBottom = '10px';
                this.errorElement.style.display = 'block';
            }
        }
    }
   private notCreate(e:MouseEvent): void {
        e.preventDefault();
        this.openNewRoute('/income');
        return;
    }
}