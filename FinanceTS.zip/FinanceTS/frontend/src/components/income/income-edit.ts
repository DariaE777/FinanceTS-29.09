import {Auth} from "../../auth";
import host from "../../config/config";
import {CategoriesResponseType} from "../../types/categories-response.type";
import {DefaultResponseType} from "../../types/default-response.type";

export class IncomeEdit {
    readonly openNewRoute: Function;
    readonly token: string | null;
    readonly refreshToken: string | null;
    private categoryEditInputElement: HTMLElement | null = document.getElementById('income-edit-input');
    private originalIncomeData: CategoriesResponseType | null = null;
    readonly incomeEditButton: HTMLElement | null = document.getElementById('income-edit');
    readonly incomeEditCancelButton: HTMLElement | null = document.getElementById('income-edit-cancel');
    constructor(openNewRoute:Function) {
        this.openNewRoute = openNewRoute;
        this.token = localStorage.getItem(Auth.accessTokenKey);
        this.refreshToken = localStorage.getItem(Auth.refreshTokenKey);
        if (!this.token || !this.refreshToken) {
            return this.openNewRoute('/login');
        }
        const urlParams: URLSearchParams = new URLSearchParams(window.location.search);
        const urlId = urlParams.get('id');
        if (urlId) {
            const id: number = parseInt(urlId);
            if (!id) {
                return this.openNewRoute('/');
            }
            if (this.incomeEditButton) {
                this.incomeEditButton.addEventListener('click', this.editIncome.bind(this));
            }
            if (this.incomeEditCancelButton) {
                this.incomeEditCancelButton .addEventListener('click', this.notEdit.bind(this));
            }
            this.getIncomeCategory(id).then();
        }
    }

    private async getIncomeCategory(id:number): Promise<Response | undefined> {
        const params: RequestInit = {
            method: 'GET',
            headers: {
                'Content-type': 'application/json',
                'Accept': 'application/json',
                'x-auth-token': this.token ?? '',
            }
        };

        const response:Response = await fetch(host + 'categories/income/' + id, params);
        const result: CategoriesResponseType | DefaultResponseType = await response.json();
        if (!result || (result as DefaultResponseType).error) {
            if (response.status === 401) {
                const updateTokenResult:Response = await fetch(host + 'refresh', {
                    method: 'POST',
                    headers: {
                        'Content-type': 'application/json',
                        'Accept': 'application/json'
                    },
                    body: JSON.stringify({refreshToken: this.refreshToken})
                });

                if (updateTokenResult.status === 200) {
                    const tokens = await updateTokenResult.json();

                    if (tokens && !tokens.error) {
                        Auth.setTokens(tokens.tokens.accessToken, tokens.tokens.refreshToken);
                        return response;
                    }
                } else {
                    Auth.removeTokens();
                    localStorage.removeItem(Auth.userInfoKey);
                    this.openNewRoute('/login');
                }
            }

        }
        (this.categoryEditInputElement as HTMLInputElement).value = (result as CategoriesResponseType).title;
        this.originalIncomeData = result as CategoriesResponseType;
    }
    private async editIncome(e:MouseEvent): Promise<Response | undefined> {
        e.preventDefault();
        const changedData: CategoriesResponseType | {} = {};
        if (this.originalIncomeData) {
            if ((this.categoryEditInputElement as HTMLInputElement).value !== this.originalIncomeData.title) {
                (changedData as CategoriesResponseType).title = (this.categoryEditInputElement as HTMLInputElement).value;
            }

            if ((changedData as CategoriesResponseType).title) {
                const params: RequestInit = {
                    method: 'PUT',
                    headers: {
                        'Content-type': 'application/json',
                        'Accept': 'application/json',
                        'x-auth-token': this.token ?? ''
                    },
                    body: JSON.stringify(changedData)
                };
                const response: Response = await fetch(host + 'categories/income/' + this.originalIncomeData.id, params);
                const result: CategoriesResponseType | DefaultResponseType = await response.json();
                if (!result || (result as DefaultResponseType).error) {
                    console.log((result as DefaultResponseType).message);
                } else {
                    return this.openNewRoute('/income');
                }
            }
        }
    }
    private notEdit(e:MouseEvent): void {
        e.preventDefault();
        this.openNewRoute('/income');
    }
}