export type  RefreshResponseType = {
    tokens: {
        accessToken: string,
        refreshToken: string
    }
}