export  type  ParamsType = {
    method: string,
    headers: {
        "Content-type": string;
        Accept: string;
        "x-auth-token": string | null
    },
    body?: string
}


